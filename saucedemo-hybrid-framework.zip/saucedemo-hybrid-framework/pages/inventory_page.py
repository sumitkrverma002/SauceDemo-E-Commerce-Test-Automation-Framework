"""
InventoryPage
-------------
Page Object for the product listing page (after successful login).
"""

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from pages.base_page import BasePage


class InventoryPage(BasePage):
    PAGE_TITLE = (By.CLASS_NAME, "title")
    INVENTORY_ITEMS = (By.CLASS_NAME, "inventory_item")
    CART_ICON = (By.CLASS_NAME, "shopping_cart_link")
    CART_BADGE = (By.CLASS_NAME, "shopping_cart_badge")
    SORT_DROPDOWN = (By.CLASS_NAME, "product_sort_container")
    ITEM_PRICES = (By.CLASS_NAME, "inventory_item_price")

    def add_item_to_cart_by_name(self, item_name):
        button_id = "add-to-cart-" + item_name.lower().replace(" ", "-")
        locator = (By.ID, button_id)
        self.click(locator)

    def get_cart_count(self):
        if self.is_visible(self.CART_BADGE):
            return int(self.get_text(self.CART_BADGE))
        return 0

    def go_to_cart(self):
        self.click(self.CART_ICON)

    def sort_products(self, option_value):
        dropdown = Select(self.find(self.SORT_DROPDOWN))
        dropdown.select_by_value(option_value)

    def get_all_prices(self):
        elements = self.driver.find_elements(*self.ITEM_PRICES)
        return [float(e.text.replace("$", "")) for e in elements]

    def is_loaded(self):
        return self.is_visible(self.PAGE_TITLE)
