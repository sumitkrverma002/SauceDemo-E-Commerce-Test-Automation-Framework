"""
CartPage
--------
Page Object for the shopping cart page.
"""

from selenium.webdriver.common.by import By
from pages.base_page import BasePage


class CartPage(BasePage):
    CART_ITEMS = (By.CLASS_NAME, "cart_item")
    ITEM_NAMES = (By.CLASS_NAME, "inventory_item_name")
    CHECKOUT_BUTTON = (By.ID, "checkout")
    REMOVE_BUTTON_PREFIX = "remove-"

    def get_item_count(self):
        return len(self.driver.find_elements(*self.CART_ITEMS))

    def get_item_names(self):
        elements = self.driver.find_elements(*self.ITEM_NAMES)
        return [e.text for e in elements]

    def remove_item_by_name(self, item_name):
        button_id = self.REMOVE_BUTTON_PREFIX + item_name.lower().replace(" ", "-")
        self.click((By.ID, button_id))

    def go_to_checkout(self):
        self.click(self.CHECKOUT_BUTTON)
