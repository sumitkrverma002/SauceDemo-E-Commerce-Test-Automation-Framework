"""
test_login.py
--------------
Data-driven login test cases. Credentials come from data/test_data.xlsx
(sheet: login_data) instead of being hardcoded — add a new row in
Excel to add a new scenario, no code change needed.
"""

import pytest
from pages.login_page import LoginPage
from pages.inventory_page import InventoryPage
from utils.excel_reader import read_excel_data

login_data = read_excel_data("test_data.xlsx", "login_data")


@pytest.mark.smoke
@pytest.mark.parametrize("row", login_data)
def test_login(driver, row):
    login_page = LoginPage(driver)
    login_page.load()
    login_page.login(row["username"], row["password"])

    if row["expected_result"] == "success":
        inventory_page = InventoryPage(driver)
        assert inventory_page.is_loaded(), f"Login should succeed for {row['username']}"
    else:
        assert login_page.is_error_displayed(), f"Expected error for {row['username']}"
        if row.get("expected_message"):
            actual_error = login_page.get_error_text()
            assert row["expected_message"] in actual_error


@pytest.mark.regression
def test_login_page_title(driver):
    login_page = LoginPage(driver)
    login_page.load()
    assert "Swag Labs" in login_page.get_title()
