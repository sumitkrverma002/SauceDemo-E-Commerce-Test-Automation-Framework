"""
test_checkout.py
-----------------
End-to-end checkout flow tests, data-driven from
data/test_data.xlsx (sheet: checkout_data).
"""

import pytest
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from utils.excel_reader import read_excel_data

checkout_data = read_excel_data("test_data.xlsx", "checkout_data")


def _add_item_and_go_to_checkout(driver):
    inventory_page = InventoryPage(driver)
    inventory_page.add_item_to_cart_by_name("Sauce Labs Backpack")
    inventory_page.go_to_cart()

    cart_page = CartPage(driver)
    cart_page.go_to_checkout()


@pytest.mark.smoke
@pytest.mark.parametrize("row", checkout_data)
def test_checkout_information_step(logged_in_driver, row):
    _add_item_and_go_to_checkout(logged_in_driver)

    checkout_page = CheckoutPage(logged_in_driver)
    checkout_page.fill_checkout_info(row["first_name"], row["last_name"], row["zip_code"])

    if row["expected_result"] == "success":
        total_text = checkout_page.get_total_text()
        assert "Total" in total_text
    else:
        assert checkout_page.is_visible(checkout_page.ERROR_MESSAGE)


@pytest.mark.regression
def test_full_checkout_flow_success(logged_in_driver):
    _add_item_and_go_to_checkout(logged_in_driver)

    checkout_page = CheckoutPage(logged_in_driver)
    checkout_page.fill_checkout_info("Sumit", "Kumar", "560001")
    checkout_page.finish_order()

    assert "Thank you for your order" in checkout_page.get_success_message()
