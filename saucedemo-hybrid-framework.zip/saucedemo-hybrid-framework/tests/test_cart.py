"""
test_cart.py
------------
Tests for add-to-cart / remove-from-cart flows. Product names are
data-driven from data/test_data.xlsx (sheet: product_data).
"""

import pytest
from pages.inventory_page import InventoryPage
from pages.cart_page import CartPage
from utils.excel_reader import read_excel_data

product_data = read_excel_data("test_data.xlsx", "product_data")


@pytest.mark.regression
@pytest.mark.parametrize("row", product_data)
def test_add_single_item_to_cart(logged_in_driver, row):
    inventory_page = InventoryPage(logged_in_driver)
    inventory_page.add_item_to_cart_by_name(row["product_name"])
    assert inventory_page.get_cart_count() == 1


@pytest.mark.regression
def test_add_multiple_items_to_cart(logged_in_driver):
    inventory_page = InventoryPage(logged_in_driver)
    for row in product_data:
        inventory_page.add_item_to_cart_by_name(row["product_name"])
    assert inventory_page.get_cart_count() == len(product_data)


@pytest.mark.regression
def test_remove_item_from_cart(logged_in_driver):
    inventory_page = InventoryPage(logged_in_driver)
    inventory_page.add_item_to_cart_by_name("Sauce Labs Backpack")
    inventory_page.go_to_cart()

    cart_page = CartPage(logged_in_driver)
    assert cart_page.get_item_count() == 1
    cart_page.remove_item_by_name("Sauce Labs Backpack")
    assert cart_page.get_item_count() == 0


@pytest.mark.smoke
def test_products_sorted_price_low_to_high(logged_in_driver):
    inventory_page = InventoryPage(logged_in_driver)
    inventory_page.sort_products("lohi")
    prices = inventory_page.get_all_prices()
    assert prices == sorted(prices)
