"""
excel_reader.py
----------------
Utility to read test data from an Excel (.xlsx) file and convert
each row into a dictionary. This is the "Data-Driven" part of the
hybrid framework — test data lives outside the code, so adding a
new test scenario means adding a row in Excel, not touching Python.
"""

import openpyxl
import os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")


def read_excel_data(file_name, sheet_name):
    """
    Reads an Excel sheet and returns a list of dicts, one per row,
    keyed by the column headers in row 1.

    Example return:
    [
        {"username": "standard_user", "password": "secret_sauce", "expected_result": "success"},
        {"username": "locked_out_user", "password": "secret_sauce", "expected_result": "fail"},
    ]
    """
    file_path = os.path.join(DATA_DIR, file_name)
    workbook = openpyxl.load_workbook(file_path, data_only=True)
    sheet = workbook[sheet_name]

    rows = list(sheet.iter_rows(values_only=True))
    headers = rows[0]
    data = []

    for row in rows[1:]:
        if row[0] is None:
            continue  # skip blank rows
        row_dict = dict(zip(headers, row))
        data.append(row_dict)

    return data
