"""
conftest.py
-----------
Shared PyTest fixtures. `driver` fixture creates a fresh Chrome
WebDriver instance for every test function and quits it afterwards,
so tests stay independent of each other.
"""

import os
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options


@pytest.fixture
def driver():
    options = Options()
    # Auto-headless on CI (GitHub Actions sets CI=true); normal
    # visible browser when running locally.
    if os.environ.get("CI"):
        options.add_argument("--headless=new")
        options.add_argument("--window-size=1920,1080")
    else:
        options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")

    drv = webdriver.Chrome(options=options)
    yield drv
    drv.quit()


@pytest.fixture
def logged_in_driver(driver):
    """A driver that's already logged in with the standard user —
    saves repeating the login steps in every cart/checkout test."""
    from pages.login_page import LoginPage

    login_page = LoginPage(driver)
    login_page.load()
    login_page.login("standard_user", "secret_sauce")
    return driver
